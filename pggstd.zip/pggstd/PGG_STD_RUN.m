% % % % %  Generating output data for plotting 

%%%%%%% the following code generate data for using main function PGG_STD
%%%%%%% write the date pggstd folder


close all;
clear all;
clc ;


%% the parameters we varied

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h = [1.5 3];

cost= [0.1 0.5];

beeta = [0.5 1 2];

int_coop = [0 10 20 30 40 50];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


itr = 30; %% iterated same experimental condition itr times
 
% % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % % %

G = 1000;  %% number of generations, which is in MAIN

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

for ii= 1:length(h)

    for jj= 1: length(cost)

        for kk =1: length(beeta)

            for ll = 1:length(int_coop)


                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                donation = zeros(G,1);
                temp_CCC  = zeros(G,1);
                temp_mean_drate = zeros(G,1);


                for n = 1:itr

                    [CCCrec,CCC_rate,drate,drate_Mean] = PGG_STD(h(ii), cost(jj), beeta(kk), int_coop(ll),G);


                    donation = (donation + drate);

                    temp_CCC = temp_CCC + CCC_rate;

                    temp_mean_drate = temp_mean_drate + drate_Mean;

                end

                don = donation./itr ;  %%% average donation rates

                ccc = temp_CCC./itr ;   %%%% average ccc values in each generation

                raw_ccc = CCCrec;      %%% to draw histograms of CCC in specified generation.

                %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

                %% Writing aym date %%%


                         x_asym = ceil(G - G*(25/100));
                
                         asym_don =  mean (don(x_asym:G)); %%% aysmtotic values of donations
                
                         asym_ccc =  mean (ccc(x_asym:G));


                         file_name = ['pggAsymDR_' [num2str(ii),'_', num2str(jj),'_',num2str(kk),'_', num2str(ll)]];  %%% creating file name
                
                         save(file_name,'asym_don' ); %% Writing in the file


                         file_name = ['pggAsymCCC_' [num2str(ii),'_', num2str(jj),'_',num2str(kk),'_', num2str(ll)]];  %%% creating file name
                
                         save(file_name,'asym_ccc' ); %% Writing in the file


                         %%% Writing date %%% evolution of donation rates and ccc
                         %%% over the generations

                         file_name = ['pggDR_' [num2str(ii),'_', num2str(jj),'_',num2str(kk),'_', num2str(ll)]] ;  %%% creating file name

                         save(file_name,'don'); %% Writing in the file



                         file_name = ['pggCCC_' [num2str(ii),'_', num2str(jj),'_',num2str(kk),'_', num2str(ll)]];  %%% creating file name
                
                         save(file_name,'ccc'); %% Writing in the file

                  
                                
                         %%% for getting raw CCC values to draw histograms
                
                         file_name = ['pggRawCCC_' [num2str(ii),'_', num2str(jj),'_',num2str(kk),'_', num2str(ll)]];  %%% creating file name
                
                
                         save(file_name,'raw_ccc' ); %% Writing in the file

            end
        end
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  
 
