function [CCCrec,CCC_rate,drate,drate_Mean] = PGG_STD(h, cost, beeta, int_coop,G)



 %%%%%%%%%% the following code models evolutionary public goods game when
 %%%%%%%%%% certain percentage of altruists present all the generations of
 %%%%%%%%%% punlic goods game
 

% The following code models the evolutionary public goods game. 

% The game involves three stages, all the agents play a public goods game, obtain payoffs, and reproduce and update their social behavior.

% The code models the following stages. Population type:  the program creates conditional cooperative criterion values of the population. 
% Conditional cooperative decision: agent cooperate with probability p = 1/(1+exp(-(Nc - CCCi)*beeta)), 
% where Nc is the number of agents cooperated in the previous generation and CCCi is agent ith conditional cooperative criterion,
% and beeta is noise level in the population. After each generation (one round of PGG) agents obtain payoffs and reproduce based on relative payoff.
% Agent i,s payoff from the public goods game is payi = (E-ui) + 1/N (sum(ui)), where E is the initial payoff of the agents and ui is the contribution 
% cost, and N is the total number of agents in the game or size of the population.

% Each agent reproduced offspring(s) with probability q = 1/(1+exp(-(payj - payi)). The updating involves 5% mutations. 

%% In the model, we introduce a fixed number of altruists whose CCC = 0 and present in all generations and do not change their behavior. 

% fixed Variable: 

%% gn -> number of generations 

%% h -> enhancing factor 

%% N -> population size

%% generation -> one round of public goods game

%% variable

%% beeta -> noise in the population, which is a population level parameter


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

pop_size = 100;  %% size of the population

N = pop_size ;
 
gn = G;     

G = gn ;    %%% number of generations
 

  min_CCC = -1; max_CCC= 100;

  t_CCC = min_CCC + (max_CCC-min_CCC).*rand(N,1); 
    
  CCC = zeros(N,1) + ceil(t_CCC);  %% Converting CCC into integers %%

  CCC_t0 = CCC;  %% initial CCC values of the population 


  cost_Contribution = -cost ;       %  the cost of contribution in the public goods game 
     
T = 2;     %% The game starts with the 2nd round as the first round starts with the initial assigned cooperation level. 

enf= h;      %% enhancing factor of the collected good 


 %% Initializing parameters to store the parameters obtained in the simulations. 

    
 trialsrec = zeros(G,1);  % for recording the number of times agents have opportunity to contribute to public goods game

 actnrec = zeros(G,1);   % for recording the number of times agents contribute to public goods game


 actnrec(1) =  int_coop ; %% Initial amount of cooperation in the first round of public goods game


 %%% recording parameters generated in specified generations 
 
 actnrec1  = zeros(N,G);
 payrec = zeros(N,G);
 payGrec = zeros(N,G);
 CCCrec = zeros(N,G);
 
 %%% each generation consisits of a round of the PGG 
 

 
for g = 1:G  %% looping over generation
    
 
    pay1   = zeros(N,1)+10;  %% initial payoffs E of agents


    for t = 2:T   %% looping over round

        payoff_PGG  = 0; %%% inital public good game in the first round
        trials = 0; %%% initial opportunities
        actn= 0;    %%% initial actions in the first round
        actn1  = zeros(N,1);  %%% for recording actions agents

        for j = 1:N
           
            %%%%%% conditional rule to cooperate %%%%%%%%%%%%%%%%%%%%%
                f = (actnrec(t-1)-CCC(j));

                p = 1./(1+exp(-(f*beeta)));  %%%% probability of contribution
           %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
           
            if CCC(j)== 0

                trials=trials+1; %% couting trials or opportunities

                actn=actn+1; %% counting actions
              
                pay1(j)=pay1(j)+cost_Contribution; %% if agent donation, will incurs cost, C

                pay1(j) = payoff_PGG + pay1(j); %% agent payoff from PGG


            elseif CCC(j)>0

                    trials=trials+1;

                    if  rand<p %% j contribute to the public good

                      actn=actn+1; %% counting actions

                      pay1(j)=pay1(j)+cost_Contribution; %% if agent donation, will incurs cost, C

                      pay1(j) = payoff_PGG + pay1(j); %% agent payoff from PGG

                     
                     end
  
            end


        end

        actnrec(t) = actn ;

        payoff_PGG = abs(cost_Contribution)*enf*sum(actnrec)/N; %% Public good %% B =C is required)

    end
 
 %% after each generation storing the parameters values
 
 payGrec(:,g)= payoff_PGG; %%% storing public good game contributions %%
 
 payrec(:,g)= pay1;
 actnrec1(:,g) =  actn1;
 
 trialsrec(g) = trials;
 actnrec(g) = actn;
 actnrec(2) =  actnrec(1);  %%  keeping first and second generation same amout of cooperatoon 

 
% % %  after each generation updating population using pairwise process 
 w  = randperm(N);
 
  for jj=1:N

      delpay = eps+pay1(w(jj))-pay1(jj);

      q = 1./(1+exp(-delpay*beeta)); %% probability of imitating based on relative payoffs

      if rand<q


          CCC((jj))= CCC(w(jj));

      end

  end


 % Adding 5% mutations
 
 % creating 100 values from Gaussian distribution with a spefified mean mu = 0 and std (sigma) 10% %% 
 
 varargin = 100;
 mx =  50;
 mn = -50;
 mu = 0;
 sigma = 10;

 mu_N =  randnlimit(mu, sigma, mn, mx, varargin) ; %% creating values to mutate %
 mu_t = ceil(mu_N(:,1)); %% converting into int due CCC values are int

 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
  %% each round certain number of unconditional cooperators are added to
  %% the population

  n_mu = 5; %% 5% mutations
 
  mu_Site = randi(N,1,n_mu); %% site of mutations

  CCC(mu_Site) =  CCC_t0(mu_Site)+ mu_t(mu_Site);   %% creating mutation)

  CCC(CCC<0)= 0; %% when the mutated value is negative, we make it zero
  CCC(CCC>100)= N; %% when the mutated value is more than 100 we make it 100


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%  


CCCrec(:,g) = CCC ;  %%% recording CCC values across generation
 
 end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


  drate = 100*(actnrec./trialsrec); %% donation rates in each generation 

  drate_Mean = mean(drate);
  
  CCC_rate = mean(CCCrec); 
  
  CCC_rate = CCC_rate';  %% record of mean CCC values of population in each generation

  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 


