
%%%%%%%%%%%%%%%%%%%%% plotting for evoluationary public goods game 

%%the data is created using Goodness_STD_RUN 


clear 
close all
clc


% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
linespec = {'r-', 'g-','b-','c-', 'm-','y-','k-','w-',};
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h = [1.5, 3];

cost= [0.1 0.5];

beeta = [0.5 1 2];

int_coop = [0 10 20 30 40 50];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% collecting data for plotting with h = 1.5 and cost = 0.5


    for b= 1:length(int_coop)

   
        don_tmp1 = load(['Desktop/pggstd/pggDR_',num2str(1),'_', num2str(2),'_',num2str(1),'_', num2str(b)]);  %% jj_kk

        donation_rates_a(:,b) = don_tmp1.don;

    end

%%%%% donation rates plotting fig 1a. 

%%% 


figure('DefaultAxesFontSize',24)


for a = 1:length(int_coop)

    hold on
    
    X1 = donation_rates_a(:,a);
    
     
    plot(X1, 'LineWidth', 2)

    legend('0%', '10%', '20%', '30%', '40%', '50%', 'Location', 'SouthEast')
%     
    axis([0 20 -5 55])

    
         xlabel('generations','FontSize', 24)
         
         ylabel('cooperation levels (%)','FontSize', 24)

ax = gca;
ax.FontSize = 24; 


[leg,att] = legend('show');
title(leg,'\alpha')
leg.Title.Visible = 'on';
         
     hold off
    
end 



%%%%%%%%%%%%%%%%%%%%%%%%%%


