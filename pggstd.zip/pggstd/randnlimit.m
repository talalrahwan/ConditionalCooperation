% clear all
% clc




 function x = randnlimit(mu, sigma, minVal, maxVal, varargin)

% 
% mu = 0;
% sigma = 0.01;
% minVal = -10 ;
% maxVal = 10;
% varargin =  ; 


assert(mu>=minVal && mu<=maxVal);
assert(sigma>0);

x = mu + sigma*randn(varargin{:});
outsideRange = x<minVal | x>maxVal;
while nnz(outsideRange)>0
   x(outsideRange) = mu + sigma*randn(nnz(outsideRange),1);
   outsideRange = x<minVal | x>maxVal;
end